# Vendored Symcon Module Helpers

Die Dateien in diesem Verzeichnis stammen aus dem gemeinsamen Repository
[`Burki24/Symcon_ModuleHelper`](https://github.com/Burki24/Symcon_ModuleHelper).

| Datei | Upstream-Version | SHA-256 |
| --- | --- | --- |
| `ConfigurationFormHelper.php` | 1.0.0 | `fa87dd4c67f43a3838fe87110387e4c1a1b98685c13403eeb52c189246045678` |
| `IPSViewHTMLPageHelper.php` | 1.2.1 | `ccd3cb992473e919538fda14aa96970176901437bd5060a005a6ffcb9a4a2a39` |
| `HelperTranslationHelper.php` | 1.0.0 | `d3deee581eca9f8eb11e9adce060170227a2dc836ee898bd134f93d27604f639` |
| `VisualizationAssetHelper.php` | 1.0.0 | `1693b2399bcf95d270a6d9a01df6534caad906497bd4ba9489916a951abaffcc` |
| `IPSViewStyleHelper.php` | 1.4.1 | `1e5d2c47180e9ca686661307ebd8b37ffac177a91d8889c593f3663d88e011e1` |
| `PersistentJsonCacheHelper.php` | 1.0.0 | `adbc7680abe814dc6c15a9cda1312cc30023073595052006662716bc0d65f2a4` |
| `VariablePresentationHelper.php` | 2.0.0 | `ce620078e72bcbffed1adfdd02e8f64baf5f2b2e8e1531e3bb1ae7b32b390fb8` |
| `VisualizationThemeHelper.php` | 1.0.0 | `81ca4cdeac42ac97cecdb73305e9f68597a6037b1d50b843df11900c96c48dbf` |

Die Kopien werden bewusst mit der Library ausgeliefert; zur Laufzeit besteht keine externe Abhängigkeit.
